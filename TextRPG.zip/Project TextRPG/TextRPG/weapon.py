class weapon:
    def __init__(self, name, description, damage, price):
        self.name = name
        self.description = description
        self.damage = damage
        self.price = price
