import random

class Player:
    def __init__(self, zonemap):
        self.name = ''
        self.health = 100
        self.attack = 10
        self.defense = 5
        self.magic_points = 20
        self.special_skill_cooldown = 0
        self.location = 'a1'
        self.game_over = False
        self.level = 1
        self.experience = 0
        self.max_health = 100
        self.max_magic_points = 20
        self.gold = 100  # Starting gold
        self.inventory = []
        self.luck = 0  # Luck stat
        self.lure = 0  # Lure stat
        self.zonemap = zonemap

        player = Player(zonemap)

    def level_up(self):
        self.level += 1
        self.attack += 5
        self.defense += 3
        self.max_health += 20
        self.max_magic_points += 10
        self.health = self.max_health
        self.magic_points = self.max_magic_points
        print(f"Congratulations! You've reached level {self.level}.")

    def gain_experience(self, amount):
        self.experience += amount
        print(f"You gained {amount} experience points.")
        if self.experience >= self.level * 100:  # Level up condition
            self.level_up()

    def show_inventory(self):
        print("Inventory:")
        for item in self.inventory:
            print(f"- {item.name}: {item.description}")

    def show_stats(self):
        print(f"Name: {self.name}")
        print(f"Level: {self.level}")
        print(f"Health: {self.health}/{self.max_health}")
        print(f"Attack: {self.attack}")
        print(f"Defense: {self.defense}")
        print(f"Magic Points: {self.magic_points}/{self.max_magic_points}")
        print(f"Gold: {self.gold}")
        print(f"Luck: {self.luck}")
        print(f"Lure: {self.lure}")

    def use_special_ability(self, target):
        raise NotImplementedError("Subclasses must implement use_special_ability method")

    def special_attack(self, target):
        raise NotImplementedError("Subclasses must implement special_attack method")

class Wizard(Player):
    def __init__(self):
        super().__init__()
        self.special_attack_name = 'Fireball'
        self.special_attack_damage = 30  # Base damage of Fireball
        self.special_attack_cooldown = 15  # Cooldown in seconds

    def use_special_ability(self, target):
        if self.magic_points >= 15:
            damage = random.randint(self.special_attack_damage - 5, self.special_attack_damage + 5)  # Add some variability to damage
            print(f"You cast {self.special_attack_name} and deal {damage} damage to {target.name}!")
            self.magic_points -= 15
            self.special_skill_cooldown = self.special_attack_cooldown  # Set cooldown
            return damage
        else:
            print("Not enough magic points to use special ability.")
            return 0

    def special_attack(self, target):
        print("You can't use special attack as a Wizard.")

class Orc(Player):
    def __init__(self):
        super().__init__()
        self.special_attack_name = 'Rage'
        self.special_attack_damage = 20  # Base damage of Rage
        self.special_attack_cooldown = 15  # Cooldown in seconds

    def use_special_ability(self, target):
        print("You activate Rage, increasing your attack for the next turn!")
        self.special_skill_cooldown = self.special_attack_cooldown  # Set cooldown
        return True

    def special_attack(self, target):
        print("You can't use special attack as an Orc.")

class Human(Player):
    def __init__(self):
        super().__init__()
        self.special_attack_name = 'Technical Power'
        self.special_attack_damage = 25  # Base damage of Technical Power
        self.special_attack_cooldown = 15  # Cooldown in seconds

    def use_special_ability(self, target):
        damage = random.randint(self.special_attack_damage - 5, self.special_attack_damage + 5)
        print(f"You use {self.special_attack_name}, dealing {damage} damage to {target.name}!")
        self.special_skill_cooldown = self.special_attack_cooldown  # Set cooldown
        return damage

    def special_attack(self, target):
        print("You can't use special attack as a Human.")

    def player_examine(Player, action):
        current_location = Player.location
        location_details = {
            'a1': "You are in a forest. You see tall trees and hear the chirping of birds.",
            'a2': "You are at the entrance of a cave. It looks dark and foreboding.",
            'b1': "You are on a narrow path. The ground is rocky, and there are bushes on either side.",
            'b2': "You find yourself in a clearing. Sunlight filters through the canopy above.",
            'b3': "You have reached a riverbank. The water flows calmly, and you can hear the sound of the stream.",
            'c1': "You are in a dense thicket. It's difficult to see far ahead.",
            'c2': "You are in a small glade. Flowers bloom around you, and butterflies flit about.",
            'c3': "You see a campsite. The remains of a fire smolder nearby, and there's a bedroll on the ground.",
            'd1': "You stand at the foot of a towering mountain. The peak disappears into the clouds above.",
        }

        if current_location in location_details:
            print(location_details[current_location])
        else:
            print("You don't find anything of interest here.")
