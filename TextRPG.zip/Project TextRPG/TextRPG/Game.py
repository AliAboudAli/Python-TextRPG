import sys
import os
import time

from weapon import weapon
from store import store
from Story import Story
from Player import Player
from Fighting import start_encounter
from Directions import player_move  # Importeer alleen de player_move functie


# Definieer zonemap hier of haal het op uit een andere bron

def main():
    # Maak een spelerobject aan
    player = player(zonemap

    # Haal zonemap op of definieer het hier
    zonemap = get_zonemap(zonemap))  #

    player_move(player, zonemap)  # Zorg ervoor dat zonemap wordt doorgegeven

    player = choose_character()
    Story.intro()
    setup_game(player)
    maingame_loop(player)

def title_screen(player):
    os.system('cls')
    print('|------------------------------|')
    print('| Welcome to the Text RPG Game |')
    print('|------------------------------|')
    print('|            -Start-           |')
    print('|            -Help-            |')
    print('|            -Quit-            |')
    print('|------------------------------|')
    title_screen_selections(player)

def help_menu(player):
    os.system('cls')
    print('|-------------------------------------------------|')
    print('| Welcome to the Text RPG Game                    |')
    print('|-------------------------------------------------|')
    print('| -Use up, down, left, right to move              |')
    print('| -Type your command to do something              |')
    print('| ^Look^ is the command to inspect something      |')
    print('|-------------------------------------------------|')
    title_screen_selections(player)

def title_screen_selections(player):
    option = input('> ')

    if option.lower() == 'start':
        start_game(player)
    elif option.lower() == 'help':
        help_menu(player)
    elif option.lower() == 'quit':
        sys.exit()
    else:
        while option not in ('start', 'help', 'quit'):
            print('Please input a valid command')
            option = input('> ')
            if option == 'start':
                start_game(player)
            elif option == 'help':
                help_menu(player)
            elif option == 'quit':
                sys.exit()

def start_game(player):
    setup_game(player)

def choose_character():
    print("Choose your character class:")
    print("1. Wizard")
    print("2. Orc")
    print("3. Human")
    choice = input("Enter the number of your choice: ")
    if choice == "1":
        return Wizard()
    elif choice == "2":
        return Orc()
    elif choice == "3":
        return Human()
    else:
        print("Invalid choice. Please try again.")
        return choose_character()

def setup_game(player):
    os.system('cls')
    question1 = 'Are you ready to start the game?'
    for character in question1:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.10)
    title_screen(player)

def prompt(player):
    print("\n" + "================================")
    print("What would you do?")
    print("Available locations:")
    for location_key in zonemap.keys():
        print(zonemap[location_key][ZONENAME])
    action = input("> ")
    acceptable_actions = ['move', 'go', 'travel', 'walk', 'quit', 'examine', 'inspect', 'interact', 'look']
    while action.lower() not in acceptable_actions:
        print("Unknown error has been detected by the action reviewer please try again!\n")
        action = input("> ")
        if action.lower() == 'quit':
            sys.exit()
        if action.lower() in ['move', 'go', 'travel', 'walk']:
            player_move(player, action.lower())
        if action.lower() in ['examine', 'inspect', 'interact', 'look']:
            player_examine(player, action.lower())

def maingame_loop(player):
    while not player.game_over:
        prompt(player)
        player.show_inventory()
        player.show_stats()
        player_input = input("What would you like to do? ")
        if player_input.lower() == 'move':
            direction = input("Which direction would you like to go? (north/south/east/west) ")
            player.move(direction)

if __name__ == "__main__":
    main()
